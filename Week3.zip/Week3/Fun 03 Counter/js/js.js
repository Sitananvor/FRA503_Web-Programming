const countDisplay = document.getElementById("counterDisplay");
const historyLog = document.getElementById("historyBox");

const upButton = document.getElementById("up");
const downButton = document.getElementById("down");
const resetButton = document.getElementById("reset");
const saveButton = document.getElementById("save");

// State
let count = 0;

const updateUI = () => (countDisplay.innerText = count);

upButton.addEventListener("click", function () {
  count += 1;
  updateUI();
});

downButton.addEventListener("click", function () {
  if (count > 0) count -= 1;
  updateUI();
});

resetButton.addEventListener("click", function () {
  count = 0;
  historyLog.innerHTML = "";
  updateUI();
});

saveButton.addEventListener("click", function () {
  const time = new Date().toString().split(" GMT")[0];

  const log = document.createElement("p");
  log.className = "logText";
  log.innerText = `[ ${time} ] : ${count}`;
  historyLog.prepend(log);
});
