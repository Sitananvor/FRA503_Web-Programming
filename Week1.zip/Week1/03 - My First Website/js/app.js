// Select all tab buttons and all page content sections
const tabs = document.querySelectorAll('.tab');
const pages = document.querySelectorAll('.page_content');

// Add a click event listener to each tab
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = tab.getAttribute('data-target');

        // Remove 'active' class from all tabs and content pages
        tabs.forEach(t => t.classList.remove('active'));
        pages.forEach(p => p.classList.remove('active'));

        // Highlight the clicked tab
        tab.classList.add('active');
        // Show the selected page by adding the 'active' class to its ID
        document.getElementById(target).classList.add('active');
    });
});